<?php

namespace Paylike\Exception;

/**
 * Class Forbidden
 *
 * @package Paylike\Exception
 */
class Forbidden extends ApiException
{

}
