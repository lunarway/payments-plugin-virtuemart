<?php

namespace Paylike\Exception;

/**
 * Class NotFound
 *
 * @package Paylike\Exception
 */
class NotFound extends ApiException
{

}
